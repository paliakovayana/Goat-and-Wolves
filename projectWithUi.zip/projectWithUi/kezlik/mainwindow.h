#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QKeyEvent>
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QPainterPath>
#include <QPointF>
#include <QBrush>
#include <QSize>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <cmath>
#include <QPixmap>
#include <QThread>

#include "wolf.h"
#include "constants.h"

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Goat *goat;
    Wolf **wolfs;
    int gameOver = 0;
    

protected:
    void paintEvent(QPaintEvent *) override;
    void timerEvent(QTimerEvent *) override;
    void keyPressEvent(QKeyEvent *) override;
    void mousePressEvent(QMouseEvent *) override;

private:
    QPoint prevWolfsCoords[NWOLFS];
    QPoint goatPrevCoords;
    void animateGoat( void );
    int goatTurnWithCheck( int , int = 0);

    void goatWin( void );
    void wolfsWin( void );

    void basicLogicOfGame( void );

    void resetToStart( void );

    void drawGrid(QPainter &);
    void onGameStart( void );
    void onGoingToMenu(void );
    bool sheffer( bool, bool );
    //void drawGoat(QPainter &);
    //void drawWolf(QPainter &, Wolf);
    void goatTurn(int);
    void goatTurn(void);
    float wolfsTurn(int = 0);
    float goatTurnMM(int);
    int wolfTurn(int , int, int = 0);
    int checkWin(void);
    void endGame(void);
    char** createAllMoves(void);
    QPoint gridToAbsCoord( QPoint );
    QPoint gridToAbsCoord( int, int );

    QPainterPath hexagon;
    QPainterPath bg;
    QPixmap wolfsImage;
    QPixmap goatImage;
    QPixmap background;
    QPixmap pole;
    //QPixmap gamebutton;
    //QPixmap button;

    QPushButton *startButton;
    QPushButton *exitButton;
    QPushButton *mainMenuButton;


    QLabel *turnLabel;
    QLabel *winnerLabel;


    QComboBox *choseDificulty;

    bool isMainMenu = 1;
    int FPS=60;
    qreal t=0;
    qreal dt= 1.0/FPS;

};
#endif // MAINWINDOW_H
