#pragma once
#include "goat.h"


class Wolf : public QLabel
{

    Q_OBJECT

public:
    Wolf(QWidget *parent = nullptr);
    Wolf(int, int, QWidget *parent = nullptr);

    int turn( int );
    void updatePosition( void );
    void undo( void );
    void clrHistory( void );

    void setPoint(QPoint);
    QPoint getCoords( void );

    bool operator==(Wolf*);
    bool operator==(Goat*);
    bool sheffer(bool, bool);

    bool compare(Wolf*, Goat*);
    bool compare(Wolf*, Wolf*);
    bool compare(Goat*, Wolf*);

    void animateWolf( void );
    void resetPrevCoords( void );

protected:
    void timerEvent(QTimerEvent *) override;
    void paintEvent(QPaintEvent *) override;

private:
    QPoint gridToAbsCoord( QPoint );
    QPoint gridToAbsCoord( int, int );
    QPoint prevWolfsCoords;
    QPoint coords;
    QVector<QPoint> history;
    int currIdx = 0;
    int FPS=60;
    qreal t=0;
    qreal dt= 1.0/FPS;
};
