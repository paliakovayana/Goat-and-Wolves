#pragma once

#include <QPoint>
#include <QPointF>
#include <QLabel>
#include <QWidget>
#include <QPainter>
#include <QRectF>
#include <QPainterPath>
#include <QDebug>
#include <QVector>
#include <QTimerEvent>

#include "constants.h"

class Goat : public QLabel
{

    Q_OBJECT

public:
    Goat(QWidget *parent = nullptr);
    Goat(int x, int y, QWidget *parent = nullptr);
    ~Goat();
    QPoint getCoords(void);
    void setPoint(QPoint);
    int turn(int);
    void updatePosition( void );
    void undo( void );
    int sheffer(int, int);
    void clrHistory( void );
    void animateGoat( void );
    void resetPrevCoords( void );

protected:
    void timerEvent(QTimerEvent *) override;
    void paintEvent(QPaintEvent *) override;

private:
    QPoint gridToAbsCoord( QPoint );
    QPoint gridToAbsCoord( int, int );
    QPoint goatPrevCoords;
    QPoint coords;
    QVector<QPoint> history;
    int currIdx = 0;
    int FPS=60;
    qreal t=0;
    qreal dt= 1.0/FPS;
};
