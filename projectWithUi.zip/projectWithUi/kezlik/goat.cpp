#include "goat.h"

Goat::Goat(QWidget *parent): QLabel(parent)
{
    coords = QPoint(0, 0);
    history.append(coords);
}

Goat::Goat(int x, int y, QWidget *parent): QLabel(parent)
{
    coords = QPoint(x, y);
    history.append(coords);
    goatPrevCoords = coords;
}

Goat::~Goat()
{

}

void Goat::resetPrevCoords( void )
{
    goatPrevCoords = coords;
}

QPoint Goat::gridToAbsCoord( QPoint a)
{
    int x = a.x();
    int y = a.y();
    return QPoint( ( 2 * x + !(y%2)  ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

QPoint Goat::gridToAbsCoord( int x, int y)
{
    return QPoint( ( 2 * x + !(y%2) ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

QPoint Goat::getCoords(void)
{
    return coords;
}

void Goat::setPoint(QPoint newCoords)
{
    if (currIdx == (history.length() - 1))
        history.append(coords);
    currIdx++;
    history[currIdx] = newCoords;
    coords = newCoords;
}

int Goat::sheffer(int a, int b)
{
    return !(a && b);
}

void Goat::clrHistory( void )
{
    history.clear();
}

int Goat::turn(int key)
{
    int error = 1;
    if ( (key==Qt::Key_Q) && ( coords.y() != 0 ) && sheffer(coords.x()==0, coords.y()%2 == 1)  ) {
        setPoint( coords - QPoint(coords.y()%2, 1) );
        error = 0;
    }

    if ( (key==Qt::Key_E) && ( coords.y() != 0 ) && sheffer(coords.x() == M, coords.y()%2 == 1) ) {
        setPoint( coords - QPoint(coords.y()%2 - 1, 1) );
        error = 0;
    }

    if ( (key==Qt::Key_Z) && (coords.y() != (TRUERAWS - 1) ) && sheffer(coords.x()==0, coords.y()%2 == 1 ) ) {
        setPoint( coords - QPoint(coords.y()%2, -1) );
        error = 0;
    }

    if ( (key==Qt::Key_C) && (coords.y() != (TRUERAWS - 1) ) && sheffer(coords.x() == M, coords.y()%2 == 1) ) {
        setPoint( coords - QPoint(coords.y()%2 - 1, -1) );
        error = 0;
    }

    if ( (key==Qt::Key_D) && (coords.x() != ( M - !(coords.y()%2) ) ) ) {
        setPoint( coords - QPoint( -1, 0 ) );
        error = 0;
    }

    if ( (key==Qt::Key_A) && (coords.x() != 0 ) ) {
        setPoint( coords - QPoint( 1, 0 ) );
        error = 0;
    }

    return error;
}

void Goat::updatePosition( void )
{
    move( gridToAbsCoord(coords) );
    update();
}

void Goat::undo(){
    if (currIdx == 0)
        return;
    currIdx--;
    coords = history[currIdx];
}

void Goat::paintEvent(QPaintEvent *)
{
    QPainter qp(this);
    float x = 2 * 1.732 * CELL_SIZE / 2.732;

    QPointF center(CELL_SIZE, CELL_SIZE*1.732/2);
    QPointF ULCorner = center - QPointF(x/2, x/2);
    if (this->pixmap().size() != QSize(0, 0)){
        qp.drawPixmap(ULCorner.x(), ULCorner.y(), x, x, this->pixmap());
    } else {
        QPointF LRCorner = center + QPointF(x/2, x/2);
        qp.drawEllipse(QRectF( ULCorner, LRCorner) );
    }
    if (drawBounds){
        qp.drawRect( QRectF ( 0, 0, this->size().width() - 1, this->size().height() - 1 ) );
    }
}
void Goat::timerEvent(QTimerEvent *e)
{
    if (t > 1){
        killTimer(e->timerId());
        goatPrevCoords = getCoords();

    }
    t+=dt;

    QPoint newCoords = gridToAbsCoord( coords ) * t + gridToAbsCoord( goatPrevCoords ) * ( 1 - t );

    move( newCoords );

    this->update();
}
void Goat::animateGoat( void )
{
    t = 0;
    startTimer(17);
}
