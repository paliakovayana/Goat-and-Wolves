#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QWidget(parent)
{
    this->setFixedSize(600, 485);

    hexagon.moveTo(CELL_SIZE, 0);
    hexagon.lineTo(CELL_SIZE/2, -CELL_SIZE*1.732/2);
    hexagon.lineTo(-CELL_SIZE/2, -CELL_SIZE*1.732/2);
    hexagon.lineTo(-CELL_SIZE, 0);
    hexagon.lineTo(-CELL_SIZE/2, CELL_SIZE*1.732/2);
    hexagon.lineTo(CELL_SIZE/2, CELL_SIZE*1.732/2);
    hexagon.closeSubpath();

    //QSize sizeOfSubWindow(( M + 1 ) * 2 * CELL_SIZE, ( 2*N + 1 ) * CELL_SIZE*1.732 );

    bg.lineTo( QPointF(0, TRUERAWS * CELL_SIZE*1.732) );
    bg.lineTo( QPointF( ( M + 1 ) * 2 * CELL_SIZE, ( 2*N + 1 ) * CELL_SIZE*1.732 ) );
    bg.lineTo( QPointF( ( M + 1 ) * 2 * CELL_SIZE, 0) );
    bg.closeSubpath();

    background=QPixmap(":/goatttt.jpg");
    wolfsImage = QPixmap(":/wolfs.png");
    goatImage= QPixmap(":/goat.png");
    pole=QPixmap(":/pole.jpg");

    goat = new Goat(M/2, TRUERAWS/2, this);
    goat->setPixmap(goatImage);

    QPoint coords = gridToAbsCoord(goat->getCoords());
    QSize size(2 * CELL_SIZE,\
               1.732 * CELL_SIZE );

    goat->setFixedSize(size);

    goat->hide();

    goat->move(coords);

    wolfs = new Wolf*[NWOLFS];

    for (int i = 0; i < (NWOLFS - 1); i++){
        wolfs[i] = new Wolf(i, TRUERAWS - 1, this);
         wolfs[i]->setPixmap(wolfsImage);
        wolfs[i]->hide();
    }
    wolfs[NWOLFS - 1] = new Wolf(M/2, TRUERAWS - 2, this);
    wolfs[NWOLFS - 1]->hide();
    wolfs[NWOLFS - 1]->setPixmap(wolfsImage);
    for (int i = 0; i < NWOLFS; i++){
        wolfs[i]->setFixedSize(size);
        wolfs[i]->move( gridToAbsCoord( wolfs[i]->getCoords() ) );
    }

    startButton = new QPushButton("Start", this);
    startButton->setStyleSheet("background-color:rgba(0, 0, 0, 70)");
    exitButton = new QPushButton("Exit", this);
    exitButton->setStyleSheet("background-color:rgba(0, 0, 0, 70)");
    mainMenuButton = new QPushButton("Back to menu",this);
    mainMenuButton->setStyleSheet("background-color:rgba(0, 0, 0, 20)");
    mainMenuButton->hide();
    turnLabel = new QLabel(this);
    turnLabel->hide();
    winnerLabel= new QLabel(this);
    winnerLabel->hide();
    choseDificulty = new QComboBox(this);
    choseDificulty->setStyleSheet("background-color:rgba(0, 0, 0, 70)");



    choseDificulty->addItem( "Hard" );
    choseDificulty->addItem("Medium");
    choseDificulty->addItem("Easy");

    startButton->setGeometry(150,40,300,100);
    exitButton->setGeometry(150,340,300,100);
    choseDificulty->setGeometry(150,190,300,100);
    turnLabel->setGeometry(400,125,200,75);


    turnLabel->setAlignment( Qt::AlignHCenter );
    turnLabel->setFont( QFont( "Berlin Sans FB", 25 ) );
    startButton->setFont( QFont( "Berlin Sans FB ", 40 ) );
    exitButton->setFont( QFont( "Berlin Sans FB", 30 ) );
    choseDificulty->setFont( QFont( "Berlin Sans FB", 30 ) );
    mainMenuButton->setFont( QFont( "Berlin Sans FB", 20 ) );

    connect(mainMenuButton, &QPushButton::clicked, this, &MainWindow::onGoingToMenu);
    connect(startButton, &QPushButton::clicked, this, &MainWindow::onGameStart);
    connect(exitButton, &QPushButton:: clicked, this, &MainWindow::close );
}

void MainWindow::onGameStart( void )
{
    goat->show();
    for (int i = 0; i < NWOLFS; i++){
        wolfs[i]->show();
    }

    startButton->hide();

    choseDificulty->hide();

    turnLabel->show();

    mainMenuButton->show();


    exitButton->setGeometry(400,0,200,75);
    mainMenuButton->setGeometry(400,200,200,75);

    isMainMenu = 0;


    update();
    wolfsTurn();
}

void MainWindow::onGoingToMenu( void )
{
    goat->hide();
    for (int i = 0; i < NWOLFS; i++){
        wolfs[i]->hide();
    }

    resetToStart();
    startButton->show();

    choseDificulty->show();

    mainMenuButton->hide();

    turnLabel->hide();

    winnerLabel->hide();

    exitButton->setGeometry(150,340,300,100);

    isMainMenu = 1;

    update();

}

void MainWindow::resetToStart( void )
{
    goat->setPoint( QPoint(M/2, TRUERAWS / 2) );
    goat->updatePosition();
    goat->resetPrevCoords();

    for (int i = 0; i < (NWOLFS - 1); i++){
        wolfs[i]->setPoint( QPoint( i, TRUERAWS - 1 ) );
        wolfs[i]->updatePosition();
    }
    wolfs[NWOLFS - 1]->setPoint( QPoint( M/2, TRUERAWS - 2 ) );
    wolfs[NWOLFS - 1]->updatePosition();



}

QPoint MainWindow::gridToAbsCoord( QPoint a)
{
    int x = a.x();
    int y = a.y();
    return QPoint( ( 2 * x + !(y%2)  ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

QPoint MainWindow::gridToAbsCoord( int x, int y)
{
    return QPoint( ( 2 * x + !(y%2) ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

void MainWindow::drawGrid(QPainter &qp)
{
    qp.fillPath(bg, Qt::yellow);

    for (int i = 0; i < (2*N + 1); i++){
        QPointF firstCenter = QPointF( CELL_SIZE * ( 2 - i%2), CELL_SIZE * 1.732/2 * (2*i + 1) );
        QPainterPath subHexagon = hexagon.translated(firstCenter);
        
        for (int j = 0; j < (M + i%2); j++){
            qp.fillPath(subHexagon, Qt::green);
            subHexagon.translate(QPointF(2 * CELL_SIZE, 0));
        }
    }
    qp.drawLine(QPoint(0, (2*N + 1) * CELL_SIZE*1.732), QPoint( ( M + 1 ) * 2 * CELL_SIZE, ( 2*N + 1 ) * CELL_SIZE*1.732 ) );
    qp.drawLine(QPoint(( M + 1 ) * 2 * CELL_SIZE, 0), QPoint( ( M + 1 ) * 2 * CELL_SIZE, ( 2*N + 1 ) * CELL_SIZE*1.732 ) );
}


void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter qp(this);
    if (!isMainMenu){

        /* Draw Grid */
        this->drawGrid(qp);

        /* Draw goat */
        goat->update();

        /* Draw wolf */
        for (int i = 0; i < NWOLFS; i++){
            wolfs[i]->update();
            /* draw pole */
            qp.drawPixmap(400,0,pole);
        }
    } else {
        qp.drawPixmap(0,0,background);
    }
}

int MainWindow::wolfTurn(int num, int dir, int withMove)
{
    if ( (num < 0) || (num >= NWOLFS) ){
        return 1;
    }
    
    int code = wolfs[num]->turn( dir );
    
    if (code)
        return 1;

    for (int i = 0; i < NWOLFS; i++){
        if (i == num)
            continue;
        if (Wolf().compare(wolfs[i], wolfs[num])){
            wolfs[num]->undo();
            return 1;
        }
    }
    if (Wolf().compare( wolfs[num], goat )){
        wolfs[num]->undo();
        return 1;
    }

    if (withMove){
        wolfs[num]->animateWolf();
    }

    return 0;
}

char** MainWindow::createAllMoves()
{
    int numOfElements = numOfDirs * NWOLFS;
    char **currDirs = new char*[numOfElements];
    for (int i = 0; i < numOfElements; i++){
        currDirs[i] = new char[2];
        currDirs[i][0] = i/2;
        currDirs[i][1] = i%2;
    }
    return currDirs;
}

float MainWindow::wolfsTurn(int depth )
{
    if (depth == 0){
        turnLabel->setText("Wolves' Turn");
        turnLabel->repaint();
    }
    if (depth == depthLim){
        float cost = this->checkWin();
        if (cost){
            return cost;
        }
        for (int i = 0; i < NWOLFS; i++){
            cost += pow(TRUERAWS - wolfs[i]->getCoords().y() - 1, 2);
        }
        cost += pow( goat->getCoords().x() - M/2 - 1, 2 );
        return cost/200.0f;
    }

    char **allDirs = this->createAllMoves();
    int numOfElements = numOfDirs * NWOLFS;
    char *deleted = new char[numOfElements];
    float min = 30;
    int minId = -1;
    int first = 1;

    for (int i = 0; i < numOfElements; i++){
        int badMove = 0;
        int moved = allDirs[i][0];

        int code = wolfTurn( allDirs[i][0], allDirs[i][1] );

        if (code){
            badMove = 1;
            deleted[i] = 1;
            delete allDirs[i];
        }

        if (!badMove){
            deleted[i] = 0;
            float status = this->checkWin();
            if (!status){
                status = this->goatTurnMM(depth);
            }
            if (first){
                min = status;
                minId = i;
                first = 0;
            } else if (status < min){
                min = status;
                delete allDirs[minId];
                deleted[minId] = 1;
                minId = i;
            } else  if ( status == min ){
                if (rand()%2){
                    delete allDirs[minId];
                    deleted[minId] = 1;
                    minId = i;
                } else {
                    delete allDirs[i];
                    deleted[i] = 1;
                }
            } else {
                delete allDirs[i];
                deleted[i] = 1;
            }
            wolfs[ moved ]->undo();
        }
    }
    if ( (!depth) /* && (minId > 0)  */){
        this->wolfTurn( allDirs[ minId ][0], allDirs[ minId ][1], 1 );
        turnLabel->setText("Goat's Turn");
    }

    for (int i = 0; i < numOfElements; i++){
        if (!deleted[i])
            delete allDirs[i];
    }

    delete allDirs;
    delete[] deleted;
    return min;
}

float MainWindow::goatTurnMM(int depth = 0)
{
    float maxMove = -30;

    for (int i = 0; i < 6; i ++){
        int code;
        switch (i){
            case 0:
                code = goat->turn(Qt::Key_Q);
                break;
            case 1:
                code = goat->turn(Qt::Key_A);
                break;
            case 2:
                code = goat->turn(Qt::Key_Z);
                break;
            case 3:
                code = goat->turn(Qt::Key_E);
                break;
            case 4:
                code = goat->turn(Qt::Key_D);
                break;
            case 5:

                code = goat->turn(Qt::Key_C);
                break;
        }
        if ( !code ){
            int badMove = 0;
            for (int j = 0; j < NWOLFS; j++){
                if (wolfs[j]->getCoords() == goat->getCoords()){
                    badMove = 1;
                    break;
                }
            }
            if (!badMove){
                float status = this->checkWin();
                if (!status){
                    status = this->wolfsTurn(depth + 1);
                }
                if (status > maxMove){
                    maxMove = status;
                }
            }
            goat->undo();
        }
    }
    return maxMove;
}

int MainWindow::checkWin( void )
{
    int isKozlikWon = 1;
    for (int i = 0; i < NWOLFS; i++){
        if (goat->getCoords().y() < wolfs[i]->getCoords().y()){
            isKozlikWon = 0;
        }
    }
    if (isKozlikWon){
        return 1;
    }
    int areWolvesWon = 1;
    if ((goat->getCoords().x()!=0) && (goat->getCoords().y()!=0) && (goat->getCoords().x()!=M))
    {
     areWolvesWon = 0;
    }
    if (areWolvesWon == 0)
    {
        return 0;
    }
    QPoint allMoves[6] = { goat->getCoords() + QPoint( -goat->getCoords().y()%2, -1 ),
                           goat->getCoords() + QPoint( 1 - goat->getCoords().y()%2 , -1 ),
                           goat->getCoords() + QPoint( -1, 0 ),
                           goat->getCoords() + QPoint( 1, 0 ),
                           goat->getCoords() + QPoint( -goat->getCoords().y()%2, 1 ),
                           goat->getCoords() + QPoint( 1 - goat->getCoords().y()%2, 1 ),
                         } ;
    for(int i=0; i<6; i++)
    {
        bool isCellEmpty = 1;
        //allMoves[i].y();
        if ( ( allMoves[i].y() >= 0 ) && (allMoves[i].x() >= 0) && ( allMoves[i].y() < TRUERAWS ) && ( allMoves[i].x() < ( M + allMoves[i].y()%2 ) ) )
        {
            for(int j=0; j<NWOLFS; j++)
            {
                if(wolfs[j]->getCoords()==allMoves[i])
                {
                  isCellEmpty = 0;
                  break;
                }
            }
        } else {
            isCellEmpty = 0;
        }
        if ( isCellEmpty){
            areWolvesWon = 0;
            break;
        }
    }

    if (areWolvesWon == 1){
        return -1;
    }
    return 0;

}

void MainWindow::endGame( void )
{
    if (gameOver)
        this->close();
    gameOver = 1;
}


void MainWindow::mousePressEvent(QMouseEvent *e)
{
    qDebug() << e->pos();
}

void MainWindow::basicLogicOfGame( void )
{
    if (gameOver){
        return;
    }

    int gameState = this->checkWin();

    if (gameState){
        if (gameState == 1){
            goatWin();
        } else {
            wolfsWin();
        }
        return;
    }


    QThread test;

   // moveToThread(  )
   // wolfTurnTest->start();

    gameState = this->checkWin();

    if (gameState){
        if (gameState == 1){
            goatWin();
        } else {
            wolfsWin();
        }
        return;
    }
}

void MainWindow::goatWin( void )
{
    qDebug() << "win";
    winnerLabel->show();
    winnerLabel->setAlignment( Qt::AlignHCenter );
    winnerLabel->setFont( QFont( "Stencil", 40 ) );
    winnerLabel->setText("Goat wins!");
    winnerLabel->setGeometry(50,225,337,125);
    gameOver = 1;
}

void MainWindow::wolfsWin( void )
{
    qDebug() << "lose";
    winnerLabel->show();
    winnerLabel->setAlignment( Qt::AlignHCenter );
    winnerLabel->setFont( QFont( "Stencil", 40 ) );
    winnerLabel->setText("Wolves win!");
    winnerLabel->setGeometry(50,225,337,125);
    gameOver = 1;
}

int MainWindow::goatTurnWithCheck( int key, int withMove )
{
    int out = goat->turn(key);
    int elligalMove = 0;

    if (out)
        return 1;

    for (int i =0; i < NWOLFS; i++){
        if (goat->getCoords() == wolfs[i]->getCoords()){
            elligalMove = 1;
            break;
        }
    }

    if (elligalMove){
        goat->undo();
        return 1;
    } else {
        goat->animateGoat();
        return 0;
    }

}

void MainWindow::keyPressEvent(QKeyEvent *e)
{   
    int key = e->key();

    if (key == Qt::Key_Escape){
        this->close();
    }

    if (!isMainMenu){
        int out = goatTurnWithCheck(key);

        if (!out){
            basicLogicOfGame();
        }
    }
}
void MainWindow::timerEvent(QTimerEvent *)
{
}
MainWindow::~MainWindow()
{
}

