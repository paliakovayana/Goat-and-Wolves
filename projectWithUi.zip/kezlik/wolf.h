#pragma once
#include "goat.h"


class Wolf : public QLabel
{

    Q_OBJECT

public:
    Wolf(QWidget *parent = nullptr);
    Wolf(int, int, QWidget *parent = nullptr);

    int turn( int );
    void updatePosition( void );
    void undo( void );
    void clrHistory( void );

    void setPoint(QPoint);
    QPoint getCoords( void );

    bool operator==(Wolf*);
    bool operator==(Goat*);
    bool sheffer(bool, bool);

    bool compare(Wolf*, Goat*);
    bool compare(Wolf*, Wolf*);
    bool compare(Goat*, Wolf*);

protected:
    void paintEvent(QPaintEvent *) override;

private:
    QPoint gridToAbsCoord( QPoint );
    QPoint gridToAbsCoord( int, int );
    QPoint coords;
    QVector<QPoint> history;
    int currIdx = 0;
};
