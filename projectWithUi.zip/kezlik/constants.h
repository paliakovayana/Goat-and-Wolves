#pragma once 

const int N = 3;
const int M = 4;
const int TRUERAWS = 2 * N + 1;
const int CELL_SIZE = 40;
static const int NWOLFS = 5;
const int WIDTH = 800;
const int HEIGHT = 600;
const int numOfDirs = 2;
const int depthLim = 4;
const bool drawBounds = 1;
