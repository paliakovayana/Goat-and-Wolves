#include "wolf.h"

Wolf::Wolf(QWidget *parent) : QLabel(parent)
{
    coords = QPoint();
    history.append(coords);
}

Wolf::Wolf(int x, int y, QWidget *parent) : QLabel(parent)
{
    coords = QPoint(x, y);   
    history.append(coords);
}

QPoint Wolf::gridToAbsCoord( QPoint a)
{
    int x = a.x();
    int y = a.y();
    return QPoint( ( 2 * x + !(y%2)  ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

QPoint Wolf::gridToAbsCoord( int x, int y)
{
    return QPoint( ( 2 * x + !(y%2) ) * CELL_SIZE, ( y * 1.732 ) * CELL_SIZE );
}

void Wolf::setPoint(QPoint newCoords)
{
    if (currIdx == (history.length() - 1))
        history.append(coords);
    currIdx++;
    history[currIdx] = newCoords;
    coords = newCoords;
}

void Wolf::clrHistory( void )
{
    history.clear();
}

QPoint Wolf::getCoords( void )
{
    return coords;
}

int Wolf::turn( int dir )
{
    /* exit codes:
       0 - no errors,
       1 - wrong dir,
       2 - can`t go to this dir
    */

    if ( (dir != 0) && (dir != 1) ){ 
        return 1;
    }

    int x = coords.x();
    int y = coords.y();

    if (y){
        if ( (dir) && sheffer(!x, y%2) ){
            setPoint( coords - QPoint( y%2, 1) );
            return 0;
        } else if ( (!dir) && sheffer(x == (M + y%2 - 1), y%2) ) {
            setPoint( coords - QPoint( y%2 - 1, 1) );
            return 0;
        }
    }
    return 2; 
}

void Wolf::updatePosition()
{
    move( gridToAbsCoord(coords) );
    update();
}

void Wolf::undo( void )
{
    if (currIdx == 0)
        return;
    currIdx--;
    coords = history[currIdx];
}




bool Wolf::sheffer(bool a, bool b)
{
    return !(a && b);
}




bool Wolf::compare( Wolf *first, Wolf *second)
{
    return (first->getCoords() == second->getCoords());
}

bool Wolf::compare( Wolf *first, Goat *second)
{
    return (first->getCoords() == second->getCoords());
}

bool Wolf::compare( Goat *first, Wolf *second)
{
    return (first->getCoords() == second->getCoords());
}




bool Wolf::operator==( Wolf *other)
{
    return (this->coords == other->getCoords());
}

bool Wolf::operator==( Goat *other)
{
    return (this->coords == other->getCoords());
}




void Wolf::paintEvent(QPaintEvent *)
{
    QPainter qp(this);

    int a = CELL_SIZE;

    QPointF  cellCenter(CELL_SIZE, CELL_SIZE*1.732/2); 

    QPainterPath wolfTriang;
    wolfTriang.moveTo( QPointF( 0,   -a/1.732  ) );
    wolfTriang.lineTo( QPointF( a/2,  a*1.732/6 ) );
    wolfTriang.lineTo( QPointF( -a/2, a*1.732/6 ) );
    wolfTriang.closeSubpath();

    qp.drawPath(wolfTriang.translated(cellCenter));

    if (drawBounds){
        qp.drawRect( QRectF( 0, 0, this->size().width() - 1, this->size().height() - 1 ) );
    }

}
